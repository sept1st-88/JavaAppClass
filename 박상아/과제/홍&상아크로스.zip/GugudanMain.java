
public class GugudanMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Gugudan gugudan = new Gugudan();
		
		gugudan.intro();
		gugudan.input();
		gugudan.calculate();
		gugudan.output();

	}

}
