package exam.test.shoppingMall;

public class ShoppingMallSystem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 10명의 같은 반 동기들을 생성
		// 5명의 친구들은 모두 컴퓨터를 구입한다
		// 나머지 5명의 친구들은 전혀 다른 가게에서 물건을 하나 구입하시오.
		// 그리고 각 친구들의 정보를 출력
		// 각 가게의 정보를 출력하시오
		
		String parkSangAh = "박상아";
		String wonAhreum = "원아름";
		String kimHong = "김홍";
		String kimHyunSuk = "김현석";
		String yangWooJin = "양우진";
		
		String leeJungJu = "이정주";
		String parkJiHun = "박지훈";
		String leeHwanSang = "이환상";
		String leeYongHun = "이용훈";
		String chaJungKyung = "차정경";
		
		System.out.println(parkSangAh + " 컴퓨터 구입");
		System.out.println(wonAhreum + " 컴퓨터 구입");
		System.out.println(kimHong + " 컴퓨터 구입");
		System.out.println(kimHyunSuk + " 컴퓨터 구입");
		System.out.println(yangWooJin + " 컴퓨터 구입");
		
		System.out.println(leeJungJu + " 핸드폰 구입");
		System.out.println(parkJiHun + " 티비 구입");
		System.out.println(leeHwanSang + " 플레이스테이션 구입");
		System.out.println(leeYongHun + " 태블릿 구입");
		System.out.println(chaJungKyung + " 이어폰 구입");
		
		System.out.println();
		System.out.println("컴퓨터 가게에서 5개의 컴퓨터를 팔았습니다.");
		
	}

}
