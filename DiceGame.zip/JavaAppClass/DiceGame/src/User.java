
public class User {
	
	String name = "";
	Dice dice = null;
	
	User() {
		
	}
	
	User(String name) {
		this.name = name;
	}

}
