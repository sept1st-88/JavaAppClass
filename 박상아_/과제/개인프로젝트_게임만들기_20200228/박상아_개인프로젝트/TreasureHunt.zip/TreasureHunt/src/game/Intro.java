package game;

public class Intro {
	
	public void introStr() {
		System.out.println("□■□■□■□■□■□■□■□■□■□■□■□■□■□■□■□■□■□■□■□■□■□■");
		System.out.println();
		System.out.println("                WELCOME!");
		System.out.println("잭스패로우와 함께 하는 보물찾기 모험에 오신것을 환영합니다.");
		System.out.println();
		System.out.println("□■□■□■□■□■□■□■□■□■□■□■□■□■□■□■□■□■□■□■□■□■□■");
	}

}
