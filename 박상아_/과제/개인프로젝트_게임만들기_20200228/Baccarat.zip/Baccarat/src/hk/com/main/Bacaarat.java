package hk.com.main;

import hk.com.game.*;

public class Bacaarat {

	public static void main(String[] args) {
	
		GameProcess gp = new GameProcess();
//		gp.playGame();
		gp.loopGame();
		
//		GameUser gu = new GameUser();
//		gu.makeUser();
		
	}

}
