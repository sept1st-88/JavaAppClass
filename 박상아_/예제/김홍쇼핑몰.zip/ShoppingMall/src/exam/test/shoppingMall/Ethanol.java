package exam.test.shoppingMall;

public class Ethanol extends Product{

	Ethanol(){
		super("에탄올", 2500, 1);
	}
	
	@Override
	public String toString() {
		return "Ethanol";
	}
}
