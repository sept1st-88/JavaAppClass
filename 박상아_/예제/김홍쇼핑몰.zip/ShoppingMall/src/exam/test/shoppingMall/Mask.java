package exam.test.shoppingMall;

public class Mask extends Product{

	Mask(){
		super("마스크", 4000 , 10);
	}
	
	@Override
	public String toString() {
		return "Mask";
	}
}
