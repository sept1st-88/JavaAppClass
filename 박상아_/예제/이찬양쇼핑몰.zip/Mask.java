package test;

// 물건을 구입할 수 있는 고객
public class Mask extends Product{

	Mask() {
		super(4000, "Mask");
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Mask";
	}
	
	
}
