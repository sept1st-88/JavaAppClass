package test;

// 물건을 구입할 수 있는 고객
public class Ethanol extends Product {

	Ethanol() {
		super(2500, "Ethanol");
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Ethanol";
	}

}
