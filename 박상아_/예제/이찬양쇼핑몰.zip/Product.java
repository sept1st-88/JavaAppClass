package test;

// 물건을 구입할 수 있는 고객
public class Product {
	int price = 0;
	String productName = "";
	
	Product(int price, String productName){
		this.price = price;
		this.productName = productName;
	}

}
